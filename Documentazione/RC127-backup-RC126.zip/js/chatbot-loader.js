// ===============================================
// RENDIMENTOBB – CHATBOT MODULE LOADER
// Production bootstrap
// ===============================================

(function () {
  "use strict";

  const IS_DEVELOPMENT =
    window.location.hostname === "localhost" ||
    window.location.hostname === "127.0.0.1";

  const debugLog = (...args) => {
    if (IS_DEVELOPMENT) {
      (void 0);
    }
  };

  const reportLoadError = (resourceType) => {
    if (IS_DEVELOPMENT) {
      (void 0);
    }
  };

  // Previene inizializzazioni multiple.
  if (window.__rbChatbotLoaded) {
    return;
  }

  window.__rbChatbotLoaded = true;

  // =============================================
  // LANGUAGE HELPER
  // =============================================

  window.rbT = function (it, en) {
    return window.currentLang === "en"
      ? (en || it)
      : it;
  };

  // =============================================
  // CSS LOADER
  // =============================================

  function loadCSS(href) {
    return new Promise((resolve) => {
      const existing = document.querySelector(
        `link[href="${href}"]`
      );

      if (existing) {
        resolve();
        return;
      }

      const css = document.createElement("link");

      css.rel = "stylesheet";
      css.href = href;

      css.onload = () => {
        debugLog("Chatbot stylesheet loaded");
        resolve();
      };

      css.onerror = () => {
        reportLoadError("stylesheet");
        resolve();
      };

      document.head.appendChild(css);
    });
  }

  // =============================================
  // SCRIPT LOADER
  // =============================================

  function loadScript(src) {
    // PDF.js is an ES module. Await its export before loading document tools.
    if(src === "/js/vendor/pdfjs/pdf.min.mjs"){
      return import(src)
        .then(pdfjs => {
          window.pdfjsLib = pdfjs;
        })
        .catch(() => {
          window.pdfjsLib = null;
          reportLoadError("PDF reader");
        });
    }

    return new Promise((resolve) => {
      const existing = document.querySelector(
        `script[src="${src}"]`
      );

      // Lo script è già dichiarato nella pagina:
      // non viene caricato una seconda volta.
      if (existing) {
        resolve();
        return;
      }

      const script = document.createElement("script");

      script.src = src;
      script.async = false;

      script.onload = () => {
        debugLog("Chatbot module loaded");
        resolve();
      };

      script.onerror = () => {
        reportLoadError("module");
        resolve();
      };

      document.body.appendChild(script);
    });
  }

  // =============================================
  // RESOURCES
  // =============================================

  const cssFiles = [
    "/css/chatbot.css?v=20261001-22"
  ];

  const scripts = [
    "/js/chatbot/knowledge-base.js",

    "/js/chatbot/knowledge/glossary.js",
    "/js/chatbot/knowledge/finance.js",
    "/js/chatbot/knowledge/risk.js",
    "/js/chatbot/knowledge/mortgages.js",
    "/js/chatbot/knowledge/shortrent.js",
    "/js/chatbot/knowledge/real-estate.js",
    "/js/chatbot/knowledge/legal.js",
    "/js/chatbot/knowledge/taxes.js",
    "/js/chatbot/knowledge/mistakes.js",
    "/js/chatbot/knowledge/beginner.js",
    "/js/chatbot/knowledge/markets.js",
    "/js/chatbot/knowledge/subscriptions.js?v=20261008-rc63",
    "/js/chatbot/knowledge/support.js",
    "/js/chatbot/knowledge/airbnb.js",
    "/js/chatbot/knowledge/roi.js",
    "/js/chatbot/knowledge/property-analysis.js",

    "/js/chatbot/market-data.js",
    "/js/chatbot/support-data.js",

    "/js/chatbot/core/query-normalizer.js?v=20261009-rc76",
    "/js/chatbot/core/semantic-router.js?v=20261009-rc76",
    "/js/chatbot/core/entity-engine.js?v=20261011-rc99",
    "/js/chatbot/core/intent-engine.js?v=20261011-rc99",
    "/js/chatbot/core/memory-engine.js?v=20261011-rc99",
    "/js/chatbot/core/conversation-engine.js?v=20261001-22",
    "/js/chatbot/core/investor-profile-engine.js?v=20261011-rc99",
    "/js/chatbot/core/score-engine.js?v=20261011-rc99",

    "/js/vendor/pdfjs/pdf.min.mjs",

    "/js/chatbot/document-engine.js?v=20261011-rc99",
    "/js/chatbot/pdf-extraction-engine.js?v=20261011-rc99",
    "/js/chatbot/pdf-parser-engine.js?v=20261014-rc124",
    "/js/chatbot/core/document-classifier.js",
    "/js/chatbot/document-reasoning-engine.js",
    "/js/chatbot/executive-narrative-engine.js",
    "/js/chatbot/reasoning-engine.js?v=20261011-rc99",
    "/js/chatbot/core/ai-brain.js?v=20261011-rc99",
    "/js/chatbot/core/executive-brain-v2.js?v=20261012-rc108",
    "/js/chatbot/core/executive-response-builder.js?v=20261012-rc108",
    "/js/chatbot/core/response-engine.js?v=20261015-rc126",
    "/js/chatbot/core/chatbot-file-dispatcher.js?v=20261001-22",
    "/js/chatbot/core/confirmed-portfolio-engine.js?v=20261008-rc59",
    "/js/chatbot/core/portal-facts-engine.js?v=20261001-28",
    "/js/chatbot/core/pms-autopilot-engine.js?v=20261014-rc120",
    "/js/chatbot/core/investment-autopilot-engine.js?v=20261011-rc104",
    "/js/chatbot/core/renovation-recovery-engine.js?v=20261009-rc76",
    "/js/chatbot/core/chatbot-orchestrator.js?v=20261014-rc121",

    "/js/chatbot/support-engine.js",
    "/js/chatbot/core/advisor-engine.js?v=20261011-rc99",

    "/js/chatbot/ui/chatbot-attachments.js?v=20261011-rc99",
    "/js/chatbot/ui/chatbot-ui.js?v=20261012-rc107",

    "/js/ai-engine.js?v=20261011-rc99"
  ];

  // =============================================
  // BOOTSTRAP
  // =============================================

  async function init() {
    for (const href of cssFiles) {
      await loadCSS(href);
    }

    for (const src of scripts) {
      await loadScript(src);
    }

    if (typeof window.initRBChatbotUI === "function") {
      window.initRBChatbotUI();
    }

    window.rbChatbotReady = true;

    document.dispatchEvent(
      new CustomEvent("rb_chatbot_ready", {
        detail: {
          ready: true
        }
      })
    );

    debugLog("RendimentoBB chatbot ready");
  }

  // =============================================
  // START
  // =============================================

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      init,
      { once: true }
    );
  } else {
    init();
  }
})();
